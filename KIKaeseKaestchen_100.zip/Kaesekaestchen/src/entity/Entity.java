package entity;

/**
 * This is an abstract class for game entities.
 *
 */
public abstract class Entity {

	protected int id;

}
