package main;

/**
 * This is only used to start the game.
 *
 */
public class Main {

	public static void main(String[] args) {
		new Game();
	}

}
