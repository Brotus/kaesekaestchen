package de.tud.cs.se.ws15.kaesekaestchen_fancy_100_ex12.entity;

/**
 * This is an abstract class for game entities.
 *
 */
public abstract class Entity {

	protected int id;

	public int getId(){
		return id;
	}
}
