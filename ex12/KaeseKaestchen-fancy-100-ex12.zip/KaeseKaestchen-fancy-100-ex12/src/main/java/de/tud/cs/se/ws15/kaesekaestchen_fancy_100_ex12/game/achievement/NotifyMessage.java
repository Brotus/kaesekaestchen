package de.tud.cs.se.ws15.kaesekaestchen_fancy_100_ex12.game.achievement;

public enum NotifyMessage {
	FANCY_ACTION_START,
	FANCY_ACTION_END, FIELD_CLOSED,
	GAME_END,
	PRIVILEGE_CHECK;
}
