package de.tud.cs.se.ws15.kaesekaestchen_fancy_100_ex12.main;

import de.tud.cs.se.ws15.kaesekaestchen_fancy_100_ex12.game.Game;

/**
 * This is only used to start the game.
 *
 */
public class Main {

	public static void main(String[] args) {
		new Game();
	}

}
