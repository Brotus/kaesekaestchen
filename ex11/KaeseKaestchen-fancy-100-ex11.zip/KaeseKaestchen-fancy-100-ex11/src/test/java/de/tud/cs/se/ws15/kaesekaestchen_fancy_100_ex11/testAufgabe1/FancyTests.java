package de.tud.cs.se.ws15.kaesekaestchen_fancy_100_ex11.testAufgabe1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({EarthQuakeStrategyTest.class, FloodingStrategyTest.class, ChineseWallStrategyTest.class})
public class FancyTests {

}
