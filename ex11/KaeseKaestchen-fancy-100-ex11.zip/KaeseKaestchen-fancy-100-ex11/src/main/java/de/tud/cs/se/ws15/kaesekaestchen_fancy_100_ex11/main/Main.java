package de.tud.cs.se.ws15.kaesekaestchen_fancy_100_ex11.main;

/**
 * This is only used to start the game.
 *
 */
public class Main {

	public static void main(String[] args) {
		new Game();
	}

}
